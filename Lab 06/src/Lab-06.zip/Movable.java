//Steven Kast, katsm
//CSE 271, Dr Bravo
//March 2, 2017
//Lab 06, Interfaces

public interface Movable {
	
	public void moveUp();
	
	public void moveDown();
	
	public void moveRight();
	
	public void moveLeft();
}
