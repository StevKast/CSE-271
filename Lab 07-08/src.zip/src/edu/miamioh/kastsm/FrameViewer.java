package edu.miamioh.kastsm;

import javax.swing.JFrame;

public class FrameViewer {

	public static void main(String[] args){
		JFrame frame = new FilledFrame();
		

		
	}
}
