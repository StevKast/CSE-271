//Steven Kast, katsm
//CSE 271, Dr Bravo
//March 2, 2017
//Project 01, Appointment Program 

public enum appointmentType {
	Onetime, Monthly, Daily
}
