package edu.miamioh.kastsm;

//Steven Kast, kastsm
//Dr. Bravo
//CSE 271 Section F
//Lab 09

import java.awt.event.ActionEvent;

public interface ActionListener {
	void actionPerformed(ActionEvent event);
}
