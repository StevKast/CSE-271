package edu.miamioh.kastsm;

//Steven Kast, kastsm
//Dr. Bravo
//CSE 271 Section F
//Lab 09

import javax.swing.JFrame;

public class billViewer {

	public static void main(String[] args) {
		JFrame frame = new FilledFrame();

	}

}
