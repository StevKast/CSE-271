package edu.miamioh.kastsm;

import javax.swing.JFrame;

public class CurrencyCalculator {
	
	public static void main(String[] args){
	
		JFrame part1 = new CurFrame();
		part1.pack();
		
		JFrame part2 = new ColorMenu();
	}	
}
